import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Пользователь сделайте свой выбор: камень, ножницы, бумага ? ");
        String game1List = scr.nextLine();
        int gamer1Num = switch (game1List) {
            case "камень" -> 0;
            case "ножницы" -> 1;
            case "бумага" -> 2;
            default -> throw new IllegalStateException("Что то пошло не так: " + game1List);
        };

        Random rnd = new Random();
        int numberProg = rnd.nextInt(2);// 0- камень , 1- ножницы, 2- бумага
        String gamer2 = switch (numberProg) {
            case 0 -> "камень";
            case 1 -> "ножницы";
            case 2 -> "бумага";
            default -> throw new IllegalStateException("Что то пошло не так: " + numberProg);
        };
        System.out.println("Программа выбрала рандомно : " + gamer2);


        System.out.println((gamer1Num != numberProg & ((gamer1Num == 0) & (numberProg ==1)) |
                ((gamer1Num == 1) & (numberProg ==2)) | ((gamer1Num == 2) & (numberProg ==0))  )? "Пользователь выйграл":
                ((gamer1Num == numberProg)? "Ничья":  "Программа выйграла") );






    }
}