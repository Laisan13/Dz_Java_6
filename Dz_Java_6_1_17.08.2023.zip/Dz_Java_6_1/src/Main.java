import life.Wedding;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь вводит, сколько лет он состоит в браке.
        // Программа должна вывести,
        // какая годовщина свадьбы будет у пользователя следующей
        // (бумажная, ситцевая, чугунная, серебряная и.д.).
        // Не обязательно указывать все годовщины, достаточно 10-15.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите сколько лет вы состоите в браке: ");
        int year = scr.nextInt();
        Wedding weddingName = switch (year) {
            case 0 -> Wedding.СИТЦЕВАЯ;
            case 1 -> Wedding.БУМАЖНАЯ;
            case 2 -> Wedding.КОЖАНАЯ;
            case 3 -> Wedding.ЛЬНЯНАЯ;
            case 4 -> Wedding.ДЕРЕВЯННАЯ;
            case 5 -> Wedding.ЧУГУННАЯ;
            case 6 -> Wedding.МЕДНАЯ;
            case 7 -> Wedding.ЖЕСТЯНАЯ;
            case 8 -> Wedding.ФАЯНСОВАЯ;
            case 9 -> Wedding.ОЛОВЯННАЯ;
            case 10 -> Wedding.СТАЛЬНАЯ;
            case 11 -> Wedding.НИКЕЛЕВАЯ;
            case 12 -> Wedding.КРУЖЕВНАЯ;
            case 13 -> Wedding.АГАТОВАЯ;
            case 14 -> Wedding.ХРУСТАЛЬНАЯ;
            default -> throw new IllegalStateException("Данных нет по данному году: " + year);
        };
        System.out.println("У вас предстоит " + weddingName + " свадьба");


    }



}

